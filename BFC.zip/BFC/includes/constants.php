<?php
    //Creating Constants
    $server = "localhost";
    $server_user = "root";
    $user_pass = "";
    $db_name = "bloodforcharity";
?>