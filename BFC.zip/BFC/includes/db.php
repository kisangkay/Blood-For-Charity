<?php 

$con = mysqli_connect("localhost","root","","forms_db");

?>