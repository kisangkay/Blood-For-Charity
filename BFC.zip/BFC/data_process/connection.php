<?php

//links DB

$conn=mysqli_connect("localhost","root","", "bloodforcharity");

if ($conn==true){
    echo "Database Connected Successfully";

}
else echo "Database Connection Error";